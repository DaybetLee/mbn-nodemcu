# ESP8266-ping
Arduino library handling ping messages for the esp8266 platform

## Installation
Search for "ESP8266-ping" name in Arduino IDE libary manager, or get the entire repository zipfile and decompress it in your libraris directory.

## Usage
See "Ping.ino" example to get a complete usage overview.